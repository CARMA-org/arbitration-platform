# Platform Evaluation Results Bundle

A self-contained snapshot of the platform-mediation evaluation, built from the
results commit in `RESULTS_COMMIT.txt`. The source revision that produced the raw
results is in `SOURCE_COMMIT.txt` and in
`experiments/platform_mediation/EXPERIMENT_MANIFEST.json`.

## Included

- `README.md`, `docs/`, and `LICENSE` (current license status).
- `src/main`, `src/test` — the runtime, contracts, services, arbitrator, the
  exact bounded-log decomposed Cobb-Douglas allocator and its tool, the
  experiment harnesses, and the full test suite.
- `scripts/joint_solver.py` — the convex solver for the four utility families.
- `experiments/platform_mediation/` — sweep driver, scenario, archetype,
  capacity-rounding and analysis code, configuration, raw per-run and per-agent
  CSVs (including `infeasible_runs.csv`), aggregate tables, figures, logs, the
  machine-readable headline (`results/headline.json`), the decomposition
  validation (`results/decomposition_validation.json`), the generated memo
  (`RESULTS_FOR_PAPER.md`), the test report, the manifest, and the headline,
  memo, validation, and consistency generators.
- `experiments/dynamic_allocation/` — the secondary solver-level simulation with
  full-precision epoch-level raw data (`results/raw/epochs_full.csv`, 40000
  rows), per-policy-seed rows, labelled aggregate tables, and logs.
- `experiments/enforcement/` — the fault-injection driver, fake solvers, and the
  per-case results with explicit trial and operation denominators.
- `experiments/joint_allocation/` — historical experiment code only (its result
  tables, figures, summaries, and logs are excluded).
- `tests/python/`, `pom.xml`, `.github/` CI.
- `SOURCE_COMMIT.txt`, `RESULTS_COMMIT.txt`.

## Excluded

`.git`, `.env` and credentials, virtual environments, build directories,
`target`, compiled classes, `__pycache__`, caches, nested archives, historical
obsolete results, temporary and smoke outputs, and any prior bundle. The manifest
enumerates and hashes the result artifacts it lists rather than every file in
this bundle.

## Reproduction

Requirements: Java 21, Maven 3.9, and a Python 3.12 interpreter with cvxpy 1.5.3,
clarabel 0.9.0, numpy 1.26.4, scipy 1.13.1, pandas 2.2.2, matplotlib 3.9.2. Point
`SOLVER_PYTHON` at that interpreter.

    export SOLVER_PYTHON=/path/to/python-with-cvxpy
    mvn -o clean test
    $SOLVER_PYTHON -m pytest tests/python -q
    mvn -o -q dependency:build-classpath -Dmdep.outputFile=cp.txt
    # Primary sweep alone (no other solver-heavy work concurrent) for clean latency
    cd experiments/platform_mediation && python3 run_sweep.py --full
    cd ../enforcement && python3 run_enforcement.py --reps 100
    cd ../dynamic_allocation && python3 run_dynamic.py --full
    cd ../platform_mediation
    python3 validate_decomposition.py
    python3 make_headline.py && python3 make_memo.py && python3 figures.py
    python3 make_test_report.py
    python3 make_manifest.py          # generated last, after all results exist
    python3 check_consistency.py --with-manifest

## Headline finding

Each seed is an independent workload draw (100 distinct workload hashes per mixed
cell). Mixed-bundle completion: a linear declaration completes far less
bundle-structured work (about 0.05-0.10) than Cobb-Douglas, CES, or Leontief
(about 0.52-0.76). The nonlinear joint policies beat linear by about +0.57, and
beat equal quotas and standard DRF by small margins (about +0.03 and +0.005 to
+0.007 respectively); equal quotas and DRF are strong comparators. The
homogeneous composition is a symmetry check with a small tie-breaking spread. The
exact decomposed Cobb-Douglas solver matches the joint solver's continuous
solution up to the solver's numerical accuracy; installed integers can differ by
a unit from independent rounding, and few run-level completion outcomes differ.
Nonlinear joint policies make some individual agents worse off than equal quotas;
no Pareto improvement is claimed. Full statement, including the dynamic and
enforcement results, is in `experiments/platform_mediation/RESULTS_FOR_PAPER.md`.
