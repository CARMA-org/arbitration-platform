# Platform Evaluation Results Bundle

A self-contained snapshot of the platform-mediation evaluation, built from the
results commit in `RESULTS_COMMIT.txt`. The source revision that produced the raw
results is in `SOURCE_COMMIT.txt` and in
`experiments/platform_mediation/EXPERIMENT_MANIFEST.json`.

## Included

- `README.md` and `docs/` — current repository and experiment documentation.
- `src/main`, `src/test` — the runtime, contracts, services, arbitrator,
  experiment harnesses, and the full test suite.
- `scripts/joint_solver.py` — the convex solver for the four utility families.
- `experiments/platform_mediation/` — sweep driver, scenario, archetype, and
  capacity-rounding code, configuration, raw per-run and per-agent CSVs, aggregate
  tables, figures, logs, the machine-readable headline (`results/headline.json`),
  the generated memo (`RESULTS_FOR_PAPER.md`), the test report, the manifest, and
  the headline/memo/consistency generators.
- `experiments/dynamic_allocation/` — the secondary solver-level simulation
  driver with complete epoch-level raw data (`results/raw/epochs_full.csv`),
  per-policy-seed rows, aggregated tables, and logs.
- `experiments/enforcement/` — the fault-injection driver, fake solvers, and the
  per-case results with explicit trial and operation denominators.
- `experiments/joint_allocation/` — the historical experiment code only (its
  result tables, figures, summaries, and logs are excluded).
- `tests/python/`, `pom.xml`, `.github/` CI.
- `SOURCE_COMMIT.txt`, `RESULTS_COMMIT.txt`, and
  `changes_since_starting_head.patch` (source, documentation, table, and summary
  changes from the starting branch head through the results commit; large raw
  CSVs are excluded from the patch because they are present verbatim).

## Excluded

`.git`, `.env` and credentials, virtual environments, `target/`, compiled
classes, `__pycache__`, dependency caches, nested archives, historical
joint-allocation results, and any file not named in the manifest.

## Reproduction

Requirements: Java 21, Maven 3.9, and a Python 3.12 interpreter with cvxpy 1.5.3,
clarabel 0.9.0, numpy 1.26.4, scipy 1.13.1, pandas 2.2.2. Point `SOLVER_PYTHON`
at that interpreter.

    export SOLVER_PYTHON=/path/to/python-with-cvxpy
    mvn -o test
    $SOLVER_PYTHON -m pytest tests/python -q
    mvn -o -q dependency:build-classpath -Dmdep.outputFile=cp.txt
    cd experiments/platform_mediation && python3 run_sweep.py --full
    python3 make_headline.py && python3 make_memo.py && python3 figures.py
    python3 make_test_report.py
    python3 make_manifest.py --source-commit "$(cat ../../SOURCE_COMMIT.txt)"
    python3 check_consistency.py --with-manifest
    cd ../enforcement && python3 run_enforcement.py --reps 100
    cd ../dynamic_allocation && python3 run_dynamic.py --full

## Headline finding

Each seed is an independent workload draw (100 distinct workload hashes per cell),
so the paired confidence intervals reflect workload variation. Mixed-bundle
completion (equal-weighted stratified bootstrap): a linear declaration completes
far less bundle-structured work (about 0.05–0.10) than Cobb-Douglas, CES, or
Leontief (about 0.52–0.76), which beat linear by about +0.57 and beat equal
quotas by +0.026 to +0.030 with 95% intervals excluding zero; DRF is a strong
comparator that roughly ties the nonlinear joint policies. The homogeneous
composition is a symmetry check (completion spread about 0.003, a rounding
artifact). The continuous joint and decomposed Cobb-Douglas solutions agree
within tolerance, but their installed integer allocations differ by up to two
units on about 47% of agent records. Full statement, including the dynamic and
enforcement results, is in `experiments/platform_mediation/RESULTS_FOR_PAPER.md`.
