# Platform Evaluation Results Bundle

This bundle is a self-contained snapshot of the platform-mediation evaluation. It
is built from the results commit recorded in `RESULTS_COMMIT.txt`; the source
revision that produced the raw results is recorded in `SOURCE_COMMIT.txt` and in
`experiments/platform_mediation/EXPERIMENT_MANIFEST.json`.

## What is included

- `README.md` and `docs/` — current repository and experiment documentation.
- `src/main` and `src/test` — the Java runtime, contracts, services, arbitrator,
  experiment harnesses, and the full test suite.
- `scripts/joint_solver.py` — the convex solver for the four utility families.
- `experiments/platform_mediation/` — the primary experiment: sweep driver,
  scenario and archetype code, configuration, raw per-run and per-agent CSVs,
  aggregated tables, figures, logs, the independent recomputation, the machine-
  readable test report, and the experiment manifest.
- `experiments/dynamic_allocation/` — the dynamic contract experiment: driver,
  raw and aggregated results, tables, and logs.
- `experiments/enforcement/` — the fault-injection driver, fake solvers, and the
  complete case results and report.
- `experiments/joint_allocation/` — the preserved historical v0.9 experiment.
- `tests/python/` — the solver test suite; `pom.xml`; `.github/` CI.
- `SOURCE_COMMIT.txt`, `RESULTS_COMMIT.txt`, and
  `changes_since_platform_evaluation_start.patch` (source, documentation, table,
  and summary changes relative to the original platform-evaluation commit).

## What is excluded

API keys, `.env` files, virtual environments, dependency caches, `target/`,
compiled classes, `__pycache__`, temporary classpath files, editor files, and the
bundle itself.

## Reproduction

Requirements: Java 21, Maven 3.9, and a Python 3.12 interpreter with cvxpy 1.5.3,
clarabel 0.9.0, numpy 1.26.4, scipy 1.13.1, pandas 2.2.2. Point `SOLVER_PYTHON`
at that interpreter.

    export SOLVER_PYTHON=/path/to/python-with-cvxpy
    mvn -o test
    $SOLVER_PYTHON -m pytest tests/python -q
    mvn -o -q dependency:build-classpath -Dmdep.outputFile=cp.txt
    cd experiments/platform_mediation && python3 run_sweep.py --full
    python3 figures.py && python3 recompute_headline.py
    python3 make_test_report.py
    python3 make_manifest.py --source-commit "$(cat ../../SOURCE_COMMIT.txt)"
    cd ../enforcement && python3 run_enforcement.py --reps 100
    cd ../dynamic_allocation && python3 run_dynamic.py --full

## Headline finding

For bundle-structured tasks under contention, joint optimization under a linear
(substitute) utility completes far less work than under complementarity-aware
utilities. Pooled task completion: linear joint 0.143; Cobb–Douglas 0.661;
Leontief 0.668; equal quotas 0.594; DRF 0.555. Cobb–Douglas and Leontief beat
linear joint by +0.518 and +0.525 completion (95% CI excludes zero) and also beat
equal quotas and DRF. CES (rho = 0.5) is intermediate. The full statement,
including the identical-regime null and the distributional effects, is in
`experiments/platform_mediation/RESULTS_FOR_PAPER.md`.
