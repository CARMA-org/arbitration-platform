# Platform Evaluation Results Bundle

A self-contained snapshot of the platform-mediation evaluation together with the
current repository source and documentation.

## The three recorded commits

- `SOURCE_COMMIT.txt` (762a0fb34fd04cbc915763d9c03cc233b00e7843) — the source revision that generated the
  canonical experiment raw data (the 2,800-run primary sweep and 40,000-row
  dynamic simulation). The manifest's `source_commit` points here.
- `RESULTS_COMMIT.txt` (5f48135578682168b5ec5cbd1e1d048de2527475) — the revision that added those
  generated results.
- `REPOSITORY_COMMIT.txt` (6e98e0c22dd67cd11d3f0921feae23804c1d3bf8) — the source revision this bundle
  is built from. It aligns legacy demos and repository claims with what the code
  and data support; it does not rerun or change the canonical raw results. The
  canonical raw data, result tables, figures, and summaries are byte-identical to
  `RESULTS_COMMIT`; only generated provenance metadata (the machine-readable test
  report and the manifest that hashes it) differ.

## Included

- `README.md`, `docs/`, and `LICENSE_STATUS.md` (a status notice, not a license
  grant).
- `src/main`, `src/test` — the runtime, contracts, services, arbitrator, the
  exact bounded-log decomposed Cobb-Douglas allocator and its tool, the
  experiment harnesses, and the full test suite.
- `scripts/joint_solver.py` — the convex solver for the four supported families.
- `experiments/platform_mediation/` — sweep driver, scenario, archetype,
  capacity-rounding and analysis code, configuration, raw per-run and per-agent
  CSVs (including `infeasible_runs.csv`), aggregate tables, figures, logs, the
  machine-readable headline, decomposition validation, the generated memo, the
  test report, the run-completion record, the manifest, and the headline, memo,
  validation, completion, claim-scan, bundle, and consistency generators.
- `experiments/dynamic_allocation/` — the secondary solver-level simulation with
  full-precision 40,000-row epoch data.
- `experiments/enforcement/` — the fault-injection driver, fake solvers, and the
  per-case results with explicit trial and operation denominators.
- `experiments/joint_allocation/` — historical experiment code only; its result
  tables, figures, summaries, and logs are excluded and are explicitly
  noncanonical. Its early constraint-saturation results motivated the narrower
  current framing but are not canonical evidence for a general joint advantage.
- `tests/python/`, `pom.xml`, `.github/` CI.

## Excluded

`.git`, `.env` and credentials, virtual environments, build directories,
`target`, compiled classes, `__pycache__`, caches, nested archives, historical
joint-allocation results, smoke and temporary outputs, and any prior bundle. The
manifest enumerates and hashes the result artifacts it lists, not every file in
this bundle.

## Reproduction

Requirements: Java 21, Maven 3.9, and a Python 3.12 interpreter with cvxpy 1.5.3,
clarabel 0.9.0, numpy 1.26.4, scipy 1.13.1, pandas 2.2.2, matplotlib 3.9.2. Point
`SOLVER_PYTHON` at that interpreter.

    export SOLVER_PYTHON=/path/to/python-with-cvxpy
    mvn -o clean test
    $SOLVER_PYTHON -m pytest tests/python -q
    mvn -o -q dependency:build-classpath -Dmdep.outputFile=cp.txt
    # Primary sweep alone (no other solver-heavy work concurrent) for clean latency
    cd experiments/platform_mediation && python3 run_sweep.py --full
    cd ../enforcement && python3 run_enforcement.py --reps 100
    cd ../dynamic_allocation && python3 run_dynamic.py --full
    cd ../platform_mediation
    python3 validate_decomposition.py
    python3 make_headline.py && python3 make_memo.py && python3 figures.py
    python3 make_test_report.py && python3 make_completion_record.py
    python3 make_manifest.py --source-commit "$(cat ../../SOURCE_COMMIT.txt)"
    python3 claim_scan.py
    python3 check_consistency.py --with-manifest

## Headline finding

Each seed is an independent workload draw. Mixed-bundle completion: a linear
declaration completes far less bundle-structured work (about 0.05-0.10) than
Cobb-Douglas, CES, or Leontief (about 0.52-0.76). The nonlinear joint policies
beat linear by about +0.57, and beat equal quotas and standard DRF by small
margins (about +0.03 and +0.005 to +0.009 respectively); equal quotas and DRF are
strong comparators. The homogeneous composition is a symmetry check with a small
tie-breaking spread. The exact decomposed Cobb-Douglas solver matches the joint
solver's continuous solution up to the solver's numerical accuracy; installed
integers can differ by a unit from independent rounding, and few run-level
completion outcomes differ. Some individual agents do worse than under equal
quotas; no Pareto improvement is claimed. Full statement is in
`experiments/platform_mediation/RESULTS_FOR_PAPER.md`.
