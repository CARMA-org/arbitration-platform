# Platform Evaluation Results Bundle

A self-contained snapshot of the platform-mediation evaluation, built from the
results commit in `RESULTS_COMMIT.txt`. The source revision that produced the raw
results is in `SOURCE_COMMIT.txt` and in
`experiments/platform_mediation/EXPERIMENT_MANIFEST.json`.

## Included

- `README.md` and `docs/` — current repository and experiment documentation.
- `src/main`, `src/test` — the runtime, contracts, services, arbitrator,
  experiment harnesses, and the full test suite.
- `scripts/joint_solver.py` — the convex solver for the four utility families.
- `experiments/platform_mediation/` — sweep driver, scenario and archetype code,
  configuration, raw per-run and per-agent CSVs, aggregate tables, figures, logs,
  the machine-readable headline (`results/headline.json`), the generated memo
  (`RESULTS_FOR_PAPER.md`), the test report, the manifest, and the
  headline/memo/consistency generators.
- `experiments/dynamic_allocation/` — the appendix operational simulation driver
  and its raw and aggregated results.
- `experiments/enforcement/` — the fault-injection driver, fake solvers, and
  complete results.
- `experiments/joint_allocation/` — the preserved historical v0.9 experiment.
- `tests/python/`, `pom.xml`, `.github/` CI.
- `SOURCE_COMMIT.txt`, `RESULTS_COMMIT.txt`, and
  `changes_since_starting_head.patch` (source, documentation, table, and summary
  changes from the starting branch head through the results commit; large raw
  CSVs are excluded from the patch because they are present verbatim).

## Excluded

API keys, `.env` files, virtual environments, dependency caches, `target/`,
compiled classes, `__pycache__`, temporary classpath files, editor files, Git
metadata, and any nested archive.

## Reproduction

Requirements: Java 21, Maven 3.9, and a Python 3.12 interpreter with cvxpy 1.5.3,
clarabel 0.9.0, numpy 1.26.4, scipy 1.13.1, pandas 2.2.2. Point `SOLVER_PYTHON`
at that interpreter.

    export SOLVER_PYTHON=/path/to/python-with-cvxpy
    mvn -o test
    $SOLVER_PYTHON -m pytest tests/python -q
    mvn -o -q dependency:build-classpath -Dmdep.outputFile=cp.txt
    cd experiments/platform_mediation && python3 run_sweep.py --full
    python3 make_headline.py && python3 make_memo.py && python3 figures.py
    python3 make_test_report.py
    python3 make_manifest.py --source-commit "$(cat ../../SOURCE_COMMIT.txt)"
    python3 check_consistency.py --with-manifest
    cd ../enforcement && python3 run_enforcement.py --reps 100
    cd ../dynamic_allocation && python3 run_dynamic.py --full

## Headline finding

Pooled task completion: joint linear 0.323; joint Cobb-Douglas 0.661; joint
Leontief 0.672; decomposed Cobb-Douglas 0.661; equal quotas 0.620; DRF 0.609;
joint CES 0.609. Cobb-Douglas and Leontief beat linear joint by +0.339 and +0.349
completion and beat equal quotas and DRF with 95% confidence intervals excluding
zero, while harming no agent relative to equal quotas. In the homogeneous
composition all policies coincide (a null). The decomposed Cobb-Douglas comparator
matches joint Cobb-Douglas exactly, so that family needs no centralized
computation; Leontief retains cross-resource coupling. The full statement,
including the dynamic and enforcement results, is in
`experiments/platform_mediation/RESULTS_FOR_PAPER.md`.
