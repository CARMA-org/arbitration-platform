# License status

No license is currently declared for the arbitration-platform repository. Until a
license is added by the repository owner, no license is granted and all rights are
reserved. Selecting an actual license remains a decision for the CARMA repository
owner.

This bundle is an internal evaluation artifact for the repository owner's own use
in preparing a paper; it is not a public distribution, and this file is a status
notice, not a license grant.
