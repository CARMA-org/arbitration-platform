# License status

No open-source license is currently declared for this repository. Publication of the source and evaluation bundle does not itself grant an open-source license. Contact the repository owner for permitted uses.
